﻿using Health_Insurance.Domain.Entities.InsuranceTreatment;

namespace Health_Insurance.Domain.Entities.Base;

public interface IInsuranceEntityService : IBaseEntityService<InsuranceEntity>
{

}