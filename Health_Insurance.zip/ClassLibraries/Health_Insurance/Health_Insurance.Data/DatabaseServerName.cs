namespace Health_Insurance.Data
{
    public enum DatabaseServerName
    {
        MainServer = 10,
        DeveloperTest = 51
    }
}